import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { Alert, AlertDescription } from './components/ui/alert';
import { toast, Toaster } from 'sonner@2.0.3';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'login' | 'forgot-password'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Basic validation
    if (!username.trim()) {
      setError('Vui lòng nhập tên đăng nhập');
      setIsLoading(false);
      return;
    }

    if (!password.trim()) {
      setError('Vui lòng nhập mật khẩu');
      setIsLoading(false);
      return;
    }

    // Simulate login process
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock authentication - in real app, this would call an API
      if (username === 'yendh' && password === '12') {
        toast.success('Đăng nhập thành công!', {
          description: 'Chào mừng bạn quay trở lại!',
          duration: 3000,
        });
        // Clear form after successful login
        setUsername('');
        setPassword('');
      } else {
        setError('Tên đăng nhập hoặc mật khẩu không đúng');
      }
    } catch (err) {
      setError('Có lỗi xảy ra, vui lòng thử lại');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Basic email validation
    if (!email.trim()) {
      setError('Vui lòng nhập địa chỉ email');
      setIsLoading(false);
      return;
    }

    const emailRegex = /^[^ -@]+@[^ -@]+\.[^ -@]+$/;
    if (!emailRegex.test(email)) {
      setError('Vui lòng nhập địa chỉ email hợp lệ');
      setIsLoading(false);
      return;
    }

    // Simulate forgot password process
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast.success('Đã gửi email khôi phục mật khẩu!');
      toast.info('Vui lòng kiểm tra hộp thư của bạn');
      setEmail('');
      setCurrentScreen('login');
    } catch (err) {
      setError('Có lỗi xảy ra, vui lòng thử lại');
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setUsername('');
    setPassword('');
    setEmail('');
    setError('');
  };

  const switchToForgotPassword = () => {
    resetForm();
    setCurrentScreen('forgot-password');
  };

  const switchToLogin = () => {
    resetForm();
    setCurrentScreen('login');
  };

  if (currentScreen === 'forgot-password') {
    return (
      <>
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
          <Card className="w-full max-w-md shadow-lg">
          <CardHeader className="space-y-1">
            <CardTitle className="text-center">Quên mật khẩu</CardTitle>
            <CardDescription className="text-center">
              Nhập email để nhận liên kết khôi phục mật khẩu
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Nhập địa chỉ email của bạn"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isLoading}
                  className="w-full"
                />
              </div>

              {error && (
                <Alert className="border-destructive/50 text-destructive dark:border-destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Button 
                type="submit" 
                className="w-full" 
                disabled={isLoading}
              >
                {isLoading ? 'Đang gửi...' : 'Gửi email khôi phục'}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <button
                type="button"
                onClick={switchToLogin}
                className="text-sm text-primary hover:underline cursor-pointer"
                disabled={isLoading}
              >
                ← Quay lại đăng nhập
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
      <Toaster position="top-right" richColors />
      </>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-1">
          <CardTitle className="text-center">Đăng nhập</CardTitle>
          <CardDescription className="text-center">
            Nhập thông tin tài khoản để đăng nhập
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Tên đăng nhập</Label>
              <Input
                id="username"
                type="text"
                placeholder="Nhập tên đăng nhập"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={isLoading}
                className="w-full"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Mật khẩu</Label>
              <Input
                id="password"
                type="password"
                placeholder="Nhập mật khẩu"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={isLoading}
                className="w-full"
              />
            </div>

            {error && (
              <Alert className="border-destructive/50 text-destructive dark:border-destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button 
              type="submit" 
              className="w-full" 
              disabled={isLoading}
            >
              {isLoading ? 'Đang đăng nhập...' : 'Đăng nhập'}
            </Button>
          </form>

          <div className="mt-4 text-center">
            <button
              type="button"
              onClick={switchToForgotPassword}
              className="text-sm text-primary hover:underline cursor-pointer"
              disabled={isLoading}
            >
              Quên mật khẩu?
            </button>
          </div>

          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground">
              Thử nghiệm với: yendh / 12
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
    <Toaster position="top-right" richColors />
    </>
  );
}